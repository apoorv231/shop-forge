'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import { useAuthStore } from '@/store/authStore';
import { hasPermission, PERMISSIONS } from '@/lib/permissions';
import { Shield, Plus, Edit, Trash2 } from 'lucide-react';

type Permission = keyof typeof PERMISSIONS;

const ALL_PERMISSIONS: Permission[] = Object.keys(PERMISSIONS) as Permission[];

const MOCK_ROLES = [
  { id: '1', name: 'BUYER', permissions: ['VIEW_PRODUCTS', 'ADD_TO_CART', 'VIEW_ORDERS'] },
  { id: '2', name: 'SELLER', permissions: ['VIEW_PRODUCTS', 'MANAGE_PRODUCTS', 'VIEW_ORDERS', 'MANAGE_ORDERS'] },
  { id: '3', name: 'ADMIN', permissions: ['VIEW_PRODUCTS', 'ADD_TO_CART', 'MANAGE_PRODUCTS', 'MANAGE_USERS', 'VIEW_ORDERS', 'MANAGE_ORDERS'] },
];

export default function PermissionManagementPage() {
  const { user } = useAuthStore();
  const [roles, setRoles] = useState(MOCK_ROLES);
  const [showModal, setShowModal] = useState(false);
  const [editingRole, setEditingRole] = useState<any>(null);

  if (!user || !hasPermission(user.role, 'MANAGE_PERMISSIONS')) {
    return (
      <>
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
          <p className="mt-2">Only SUPERADMIN can access permission management.</p>
        </div>
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-red-600" />
            <h1 className="text-2xl font-bold">Permission Management</h1>
          </div>
          <button
            onClick={() => { setEditingRole(null); setShowModal(true); }}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Create Role
          </button>
        </div>

        <div className="grid gap-6">
          {roles.map((role) => (
            <div key={role.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{role.name}</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => { setEditingRole(role); setShowModal(true); }}
                    className="p-2 hover:bg-gray-100 rounded"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {role.permissions.map((perm) => (
                  <span key={perm} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                    {perm}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Create/Edit Role Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
              <h2 className="text-xl font-bold mb-4">
                {editingRole ? 'Edit Role' : 'Create New Role'}
              </h2>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Role Name</label>
                  <input
                    type="text"
                    defaultValue={editingRole?.name}
                    className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="e.g., MODERATOR"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Permissions</label>
                  <div className="space-y-2 max-h-60 overflow-y-auto border rounded-md p-4">
                    {ALL_PERMISSIONS.map((perm) => (
                      <label key={perm} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          defaultChecked={editingRole?.permissions.includes(perm)}
                          className="rounded"
                        />
                        <span className="text-sm">{perm}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-red-600 text-white py-2 rounded-md hover:bg-red-700"
                  >
                    {editingRole ? 'Update Role' : 'Create Role'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 border border-gray-300 py-2 rounded-md hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
