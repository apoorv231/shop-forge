'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import { useAuthStore } from '@/store/authStore';
import { hasPermission } from '@/lib/permissions';
import { Package, Eye } from 'lucide-react';

const MOCK_BUYER_ORDERS = [
  { id: '1', date: '2024-05-20', total: 3597, status: 'Delivered', items: 3 },
  { id: '2', date: '2024-05-18', total: 1999, status: 'Shipped', items: 1 },
  { id: '3', date: '2024-05-15', total: 2598, status: 'Processing', items: 2 },
];

export default function BuyerOrdersPage() {
  const { user } = useAuthStore();
  const [orders] = useState(MOCK_BUYER_ORDERS);

  if (!user || !hasPermission(user.role, 'VIEW_ORDERS')) {
    return (
      <>
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
        </div>
      </>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered': return 'bg-green-100 text-green-800';
      case 'Shipped': return 'bg-blue-100 text-blue-800';
      case 'Processing': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <>
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center gap-3 mb-6">
          <Package className="w-8 h-8 text-red-600" />
          <h1 className="text-2xl font-bold">My Orders</h1>
        </div>

        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-500">Order #{order.id}</p>
                  <p className="text-sm text-gray-500">Placed on {order.date}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                  {order.status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{order.items} items</p>
                  <p className="text-xl font-bold">₹{order.total}</p>
                </div>
                <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-gray-50">
                  <Eye className="w-4 h-4" />
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
