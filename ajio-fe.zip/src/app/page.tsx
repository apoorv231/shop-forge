import Header from '@/components/Header';
import Link from 'next/link';
import { ArrowRight, TrendingUp, Zap } from 'lucide-react';

export default function Home() {
  return (
    <>
      <Header />
      <main>
        {/* Hero Banner */}
        <div className="relative bg-gradient-to-br from-red-600 via-pink-600 to-purple-600 text-white py-24 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-10"></div>
          <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">New Season Collection</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              AJIO EXCLUSIVE
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-white/90 max-w-2xl mx-auto">
              Discover the latest trends in fashion & lifestyle
            </p>
            <Link href="/products" className="inline-flex items-center gap-2 bg-white text-red-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl">
              SHOP NOW
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>

        {/* Categories */}
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Shop by Category</h2>
            <Link href="/products" className="text-red-600 font-medium hover:underline">View All</Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'MEN', gradient: 'from-blue-500 to-blue-600' },
              { name: 'WOMEN', gradient: 'from-pink-500 to-pink-600' },
              { name: 'KIDS', gradient: 'from-yellow-500 to-orange-500' },
              { name: 'ACCESSORIES', gradient: 'from-purple-500 to-purple-600' }
            ].map((cat) => (
              <Link key={cat.name} href={`/products?category=${cat.name.toLowerCase()}`}>
                <div className={`aspect-square bg-gradient-to-br ${cat.gradient} rounded-2xl flex items-center justify-center hover:scale-105 transition-transform shadow-lg hover:shadow-xl cursor-pointer`}>
                  <span className="text-3xl font-bold text-white">{cat.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Featured Products */}
        <div className="bg-white py-16">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp className="w-8 h-8 text-red-600" />
              <h2 className="text-3xl font-bold">Trending Now</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Link key={i} href={`/products/${i}`}>
                  <div className="card overflow-hidden group">
                    <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <span className="text-gray-400 font-medium">Product {i}</span>
                    </div>
                    <div className="p-4">
                      <p className="text-xs text-gray-500 uppercase tracking-wide">Brand Name</p>
                      <h3 className="font-semibold mt-1 group-hover:text-red-600 transition-colors">Stylish Product Name</h3>
                      <div className="flex items-center gap-2 mt-2">
                        <p className="text-xl font-bold">₹1,299</p>
                        <p className="text-sm text-gray-400 line-through">₹2,599</p>
                        <span className="text-xs text-green-600 font-semibold">(50% OFF)</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Brands */}
        <div className="max-w-7xl mx-auto px-4 py-16">
          <h2 className="text-3xl font-bold mb-8">Top Brands</h2>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
            {['AJIO', 'Nike', 'Adidas', 'Puma', 'Levi\'s', 'H&M'].map((brand) => (
              <div key={brand} className="card p-6 text-center hover:border-red-600 transition-all cursor-pointer group">
                <span className="font-bold text-lg group-hover:text-red-600 transition-colors">{brand}</span>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-lg mb-4">AJIO</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">About Us</li>
                <li className="hover:text-white transition-colors cursor-pointer">Contact Us</li>
                <li className="hover:text-white transition-colors cursor-pointer">Careers</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">HELP</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Track Order</li>
                <li className="hover:text-white transition-colors cursor-pointer">Returns</li>
                <li className="hover:text-white transition-colors cursor-pointer">FAQs</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">SHOP</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Men</li>
                <li className="hover:text-white transition-colors cursor-pointer">Women</li>
                <li className="hover:text-white transition-colors cursor-pointer">Kids</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">FOLLOW US</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Facebook</li>
                <li className="hover:text-white transition-colors cursor-pointer">Instagram</li>
                <li className="hover:text-white transition-colors cursor-pointer">Twitter</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
            <p>© 2024 AJIO. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
}
