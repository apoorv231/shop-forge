'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import { ShoppingBag, Heart, Truck, Shield, RotateCcw, Star } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { hasPermission } from '@/lib/permissions';

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const [selectedSize, setSelectedSize] = useState('');
  const { user } = useAuthStore();
  
  const product = {
    id: params.id,
    name: 'Slim Fit Casual Shirt',
    brand: 'AJIO',
    price: 1299,
    mrp: 2599,
    discount: 50,
    rating: 4.5,
    reviews: 234,
    description: 'A comfortable slim fit shirt perfect for casual occasions. Made with premium cotton fabric.',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    images: ['/placeholder.jpg'],
  };

  const canAddToCart = user && hasPermission(user.role, 'ADD_TO_CART');

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Please select a size');
      return;
    }
    alert('Added to cart!');
  };

  return (
    <>
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="card aspect-square bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mb-4">
              <span className="text-gray-400 text-lg">Product Image</span>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square bg-gray-200 rounded-lg cursor-pointer hover:ring-2 hover:ring-red-600 transition"></div>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div>
            <div className="mb-4">
              <p className="text-gray-500 text-sm uppercase tracking-wide">{product.brand}</p>
              <h1 className="text-3xl font-bold mt-2">{product.name}</h1>
              <div className="flex items-center gap-3 mt-3">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">{product.rating}</span>
                </div>
                <span className="text-gray-500">|</span>
                <span className="text-gray-600">{product.reviews} reviews</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4 py-6 border-y">
              <span className="text-4xl font-bold">₹{product.price}</span>
              <span className="text-xl text-gray-400 line-through">₹{product.mrp}</span>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                {product.discount}% OFF
              </span>
            </div>

            <p className="text-gray-600 mt-6 leading-relaxed">{product.description}</p>

            {/* Size Selection */}
            <div className="mt-8">
              <h3 className="font-bold text-lg mb-4">SELECT SIZE</h3>
              <div className="flex gap-3">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-14 h-14 border-2 rounded-lg font-semibold transition-all ${
                      selectedSize === size 
                        ? 'border-red-600 bg-red-50 text-red-600 scale-105' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 mt-8">
              {canAddToCart ? (
                <>
                  <button onClick={handleAddToCart} className="btn-primary flex-1 flex items-center justify-center gap-2">
                    <ShoppingBag className="w-5 h-5" />
                    ADD TO BAG
                  </button>
                  <button className="btn-secondary px-6">
                    <Heart className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <div className="w-full text-center py-4 bg-gray-100 rounded-lg text-gray-600 font-medium">
                  Please login as Buyer to add to cart
                </div>
              )}
            </div>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 mt-8 p-6 bg-gray-50 rounded-xl">
              <div className="text-center">
                <Truck className="w-6 h-6 mx-auto text-red-600 mb-2" />
                <p className="text-xs font-medium">Free Delivery</p>
              </div>
              <div className="text-center">
                <RotateCcw className="w-6 h-6 mx-auto text-red-600 mb-2" />
                <p className="text-xs font-medium">Easy Returns</p>
              </div>
              <div className="text-center">
                <Shield className="w-6 h-6 mx-auto text-red-600 mb-2" />
                <p className="text-xs font-medium">Secure Payment</p>
              </div>
            </div>

            {/* Product Details */}
            <div className="mt-8 card p-6">
              <h3 className="font-bold text-lg mb-4">PRODUCT DETAILS</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-red-600">•</span>
                  <span>100% Premium Cotton</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600">•</span>
                  <span>Machine Wash</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600">•</span>
                  <span>Slim Fit</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-600">•</span>
                  <span>Perfect for Casual Wear</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
