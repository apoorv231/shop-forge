'use client';

import { useState } from 'react';
import { Filter, ChevronDown, SlidersHorizontal } from 'lucide-react';
import Header from '@/components/Header';
import Link from 'next/link';

const MOCK_PRODUCTS = [
  { id: '1', name: 'Slim Fit Shirt', price: 1299, mrp: 2599, brand: 'AJIO', image: '/placeholder.jpg', category: 'Shirts' },
  { id: '2', name: 'Casual Jeans', price: 1999, mrp: 3999, brand: 'Denim Co', image: '/placeholder.jpg', category: 'Jeans' },
  { id: '3', name: 'Formal Trousers', price: 1599, mrp: 2999, brand: 'AJIO', image: '/placeholder.jpg', category: 'Trousers' },
  { id: '4', name: 'Cotton T-Shirt', price: 599, mrp: 1299, brand: 'Basics', image: '/placeholder.jpg', category: 'T-Shirts' },
  { id: '5', name: 'Polo Shirt', price: 899, mrp: 1799, brand: 'AJIO', image: '/placeholder.jpg', category: 'Shirts' },
  { id: '6', name: 'Chinos', price: 1799, mrp: 3599, brand: 'Denim Co', image: '/placeholder.jpg', category: 'Trousers' },
];

export default function ProductsPage() {
  const [showFilters, setShowFilters] = useState(false);

  return (
    <>
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Filters Sidebar */}
          <aside className={`${showFilters ? 'block' : 'hidden'} md:block w-64 flex-shrink-0`}>
            <div className="sticky top-24 card p-6">
              <div className="flex items-center gap-2 mb-6">
                <SlidersHorizontal className="w-5 h-5 text-red-600" />
                <h3 className="font-bold text-lg">FILTERS</h3>
              </div>

              <div className="space-y-6">
                <div className="pb-6 border-b">
                  <button className="flex items-center justify-between w-full mb-3 font-semibold">
                    <span>Category</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  <div className="space-y-3">
                    {['Shirts', 'Jeans', 'Trousers', 'T-Shirts'].map((cat) => (
                      <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                        <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-red-600 focus:ring-red-500" />
                        <span className="text-sm group-hover:text-red-600 transition-colors">{cat}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pb-6 border-b">
                  <button className="flex items-center justify-between w-full mb-3 font-semibold">
                    <span>Brand</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  <div className="space-y-3">
                    {['AJIO', 'Denim Co', 'Basics'].map((brand) => (
                      <label key={brand} className="flex items-center gap-3 cursor-pointer group">
                        <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-red-600 focus:ring-red-500" />
                        <span className="text-sm group-hover:text-red-600 transition-colors">{brand}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="font-semibold block mb-3">Price Range</span>
                  <input type="range" min="0" max="5000" className="w-full accent-red-600" />
                  <div className="flex justify-between text-sm text-gray-600 mt-2">
                    <span>₹0</span>
                    <span>₹5000</span>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <main className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold">{MOCK_PRODUCTS.length} Products</h1>
                <p className="text-sm text-gray-600 mt-1">Showing all available products</p>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="md:hidden btn-secondary py-2"
                >
                  <Filter className="w-5 h-5" />
                </button>
                <select className="input-field py-2 text-sm">
                  <option>Sort by: Relevance</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Newest First</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {MOCK_PRODUCTS.map((product, index) => (
                <Link key={product.id} href={`/products/${product.id}`}>
                  <div 
                    className="card overflow-hidden group cursor-pointer animate-slide-up"
                    style={{ animationDelay: `${index * 50}ms` }}
                  >
                    <div className="relative aspect-square bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                      <div className="absolute inset-0 flex items-center justify-center text-gray-400">Image</div>
                      <div className="absolute top-3 right-3 bg-red-600 text-white text-xs px-3 py-1 rounded-full font-bold shadow-lg">
                        {Math.round((1 - product.price / product.mrp) * 100)}% OFF
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <div className="absolute bottom-3 left-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all">
                        <button className="flex-1 bg-white text-gray-900 py-2 rounded-lg text-sm font-semibold hover:bg-gray-100">
                          Quick View
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">{product.brand}</p>
                      <h3 className="font-bold text-sm mt-1 group-hover:text-red-600 transition-colors line-clamp-2 min-h-[2.5rem]">
                        {product.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-3">
                        <p className="text-xl font-bold">₹{product.price}</p>
                        <p className="text-sm text-gray-400 line-through">₹{product.mrp}</p>
                      </div>
                      <div className="mt-3 flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-400">★</span>
                          <span className="text-sm font-semibold">4.5</span>
                        </div>
                        <span className="text-gray-400 text-sm">|</span>
                        <span className="text-sm text-gray-600">234 reviews</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </main>
        </div>
      </div>
    </>
  );
}
