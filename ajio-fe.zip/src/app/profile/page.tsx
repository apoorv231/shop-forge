'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import { useAuthStore } from '@/store/authStore';
import { User, Mail, Phone, MapPin, Edit2, Save, ShoppingBag, Package, Heart, Settings } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function ProfilePage() {
  const { user } = useAuthStore();
  const router = useRouter();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '+91 98765 43210',
    address: '123 Main Street, Mumbai, Maharashtra',
    pincode: '400001'
  });

  if (!user) {
    router.push('/login');
    return null;
  }

  const handleSave = () => {
    setIsEditing(false);
    alert('Profile updated successfully!');
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-red-50/20 py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="card p-8 text-center animate-slide-up">
                <div className="w-32 h-32 bg-gradient-to-br from-red-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                  <User className="w-16 h-16 text-white" />
                </div>
                <h2 className="text-2xl font-bold mb-2">{user.name}</h2>
                <p className="text-gray-600 mb-1">{user.email}</p>
                <span className="inline-block px-4 py-1.5 bg-red-100 text-red-600 rounded-full text-sm font-semibold mt-3">
                  {user.role}
                </span>
                
                <div className="mt-8 pt-8 border-t space-y-4">
                  <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <ShoppingBag className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">My Orders</span>
                  </button>
                  <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <Heart className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">Wishlist</span>
                  </button>
                  <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <Settings className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">Settings</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <div className="card p-8 animate-slide-in">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-bold">Personal Information</h3>
                  {!isEditing ? (
                    <button onClick={() => setIsEditing(true)} className="btn-secondary flex items-center gap-2">
                      <Edit2 className="w-4 h-4" />
                      Edit
                    </button>
                  ) : (
                    <button onClick={handleSave} className="btn-primary flex items-center gap-2">
                      <Save className="w-4 h-4" />
                      Save
                    </button>
                  )}
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        disabled={!isEditing}
                        className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-red-500 disabled:bg-gray-50 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        disabled={!isEditing}
                        className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-red-500 disabled:bg-gray-50 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        disabled={!isEditing}
                        className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-red-500 disabled:bg-gray-50 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Address</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-4 w-5 h-5 text-gray-400" />
                      <textarea
                        value={formData.address}
                        onChange={(e) => setFormData({...formData, address: e.target.value})}
                        disabled={!isEditing}
                        rows={3}
                        className="w-full pl-12 pr-4 py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-red-500 disabled:bg-gray-50 resize-none transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Pincode</label>
                    <input
                      type="text"
                      value={formData.pincode}
                      onChange={(e) => setFormData({...formData, pincode: e.target.value})}
                      disabled={!isEditing}
                      className="w-full px-4 py-4 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-red-500 disabled:bg-gray-50 transition-colors"
                    />
                  </div>
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-6 animate-slide-in" style={{ animationDelay: '100ms' }}>
                <div className="card p-6 text-center">
                  <div className="w-14 h-14 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <ShoppingBag className="w-7 h-7 text-red-600" />
                  </div>
                  <p className="text-3xl font-bold mb-1">12</p>
                  <p className="text-gray-600 text-sm">Total Orders</p>
                </div>
                <div className="card p-6 text-center">
                  <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Package className="w-7 h-7 text-green-600" />
                  </div>
                  <p className="text-3xl font-bold mb-1">8</p>
                  <p className="text-gray-600 text-sm">Delivered</p>
                </div>
                <div className="card p-6 text-center">
                  <div className="w-14 h-14 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-7 h-7 text-pink-600" />
                  </div>
                  <p className="text-3xl font-bold mb-1">24</p>
                  <p className="text-gray-600 text-sm">Wishlist</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
