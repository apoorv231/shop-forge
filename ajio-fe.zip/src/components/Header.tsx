'use client';

import Link from 'next/link';
import { useAuthStore } from '@/store/authStore';
import { Search, ShoppingBag, User, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const [showMenu, setShowMenu] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="bg-gradient-to-r from-red-600 to-pink-600 text-white text-xs py-2 px-4 text-center font-medium">
        ✨ Free Shipping on orders above ₹999 | Extra 10% off on first order
      </div>
      
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-6">
          <Link href="/" className="text-3xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            AJIO
          </Link>
          
          <nav className="hidden lg:flex gap-8 text-sm font-semibold">
            <Link href="/products?gender=men" className="hover:text-red-600 transition-colors">MEN</Link>
            <Link href="/products?gender=women" className="hover:text-red-600 transition-colors">WOMEN</Link>
            <Link href="/products?gender=kids" className="hover:text-red-600 transition-colors">KIDS</Link>
            {user?.role === 'SELLER' && (
              <>
                <Link href="/seller/products" className="hover:text-red-600 transition-colors">MY PRODUCTS</Link>
                <Link href="/seller/orders" className="hover:text-red-600 transition-colors">ORDERS</Link>
              </>
            )}
            {(user?.role === 'ADMIN' || user?.role === 'SUPERADMIN') && (
              <>
                <Link href="/admin/users" className="hover:text-red-600 transition-colors">USERS</Link>
                {user?.role === 'SUPERADMIN' && (
                  <Link href="/admin/permissions" className="hover:text-red-600 transition-colors">PERMISSIONS</Link>
                )}
              </>
            )}
          </nav>

          <div className="flex-1 max-w-xl hidden md:block">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search for products, brands and more"
                className="w-full pl-12 pr-4 py-3 bg-gray-50 border-0 rounded-full focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-6">
            {isAuthenticated ? (
              <div className="relative">
                <button 
                  onClick={() => setShowMenu(!showMenu)} 
                  className="flex items-center gap-2 hover:text-red-600 transition-colors"
                >
                  <div className="w-9 h-9 bg-gradient-to-r from-red-600 to-pink-600 rounded-full flex items-center justify-center text-white font-semibold">
                    {user?.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden lg:block font-medium">{user?.name}</span>
                </button>
                {showMenu && (
                  <div className="absolute right-0 mt-3 w-56 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
                    <div className="p-4 bg-gradient-to-r from-red-50 to-pink-50 border-b">
                      <p className="font-semibold">{user?.name}</p>
                      <p className="text-xs text-gray-600 mt-1">{user?.email}</p>
                      <span className="inline-block mt-2 px-3 py-1 bg-white rounded-full text-xs font-medium text-red-600">
                        {user?.role}
                      </span>
                    </div>
                    <Link href="/profile" className="block px-4 py-3 hover:bg-gray-50 transition-colors">Profile</Link>
                    {user?.role === 'BUYER' && (
                      <Link href="/orders" className="block px-4 py-3 hover:bg-gray-50 transition-colors">My Orders</Link>
                    )}
                    <button onClick={logout} className="w-full text-left px-4 py-3 hover:bg-red-50 text-red-600 transition-colors">
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link href="/login" className="flex items-center gap-2 hover:text-red-600 transition-colors font-medium">
                <User className="w-5 h-5" />
                <span className="hidden lg:block">Sign In</span>
              </Link>
            )}
            
            <Link href="/cart" className="relative hover:text-red-600 transition-colors">
              <ShoppingBag className="w-6 h-6" />
              <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-semibold">
                0
              </span>
            </Link>

            <button 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="lg:hidden"
            >
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {showMobileMenu && (
        <div className="lg:hidden border-t bg-white">
          <nav className="flex flex-col p-4 space-y-2">
            <Link href="/products?gender=men" className="py-2 hover:text-red-600 font-medium">MEN</Link>
            <Link href="/products?gender=women" className="py-2 hover:text-red-600 font-medium">WOMEN</Link>
            <Link href="/products?gender=kids" className="py-2 hover:text-red-600 font-medium">KIDS</Link>
          </nav>
        </div>
      )}
    </header>
  );
}
